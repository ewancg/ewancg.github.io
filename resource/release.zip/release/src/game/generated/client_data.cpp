#include "client_data.h"
static CDataSound x1893[] = {
	/* x1893[0] */ {  0,  "audio/wp_gun_fire-01.wv", },
	/* x1893[1] */ {  0,  "audio/wp_gun_fire-02.wv", },
	/* x1893[2] */ {  0,  "audio/wp_gun_fire-03.wv", },
};
static CDataSound x1909[] = {
	/* x1909[0] */ {  0,  "audio/wp_shotty_fire-01.wv", },
	/* x1909[1] */ {  0,  "audio/wp_shotty_fire-02.wv", },
	/* x1909[2] */ {  0,  "audio/wp_shotty_fire-03.wv", },
};
static CDataSound x1925[] = {
	/* x1925[0] */ {  0,  "audio/wp_flump_launch-01.wv", },
	/* x1925[1] */ {  0,  "audio/wp_flump_launch-02.wv", },
	/* x1925[2] */ {  0,  "audio/wp_flump_launch-03.wv", },
};
static CDataSound x1941[] = {
	/* x1941[0] */ {  0,  "audio/wp_hammer_swing-01.wv", },
	/* x1941[1] */ {  0,  "audio/wp_hammer_swing-02.wv", },
	/* x1941[2] */ {  0,  "audio/wp_hammer_swing-03.wv", },
};
static CDataSound x1957[] = {
	/* x1957[0] */ {  0,  "audio/wp_hammer_hit-01.wv", },
	/* x1957[1] */ {  0,  "audio/wp_hammer_hit-02.wv", },
	/* x1957[2] */ {  0,  "audio/wp_hammer_hit-03.wv", },
};
static CDataSound x1973[] = {
	/* x1973[0] */ {  0,  "audio/wp_ninja_attack-01.wv", },
	/* x1973[1] */ {  0,  "audio/wp_ninja_attack-02.wv", },
	/* x1973[2] */ {  0,  "audio/wp_ninja_attack-03.wv", },
};
static CDataSound x1989[] = {
	/* x1989[0] */ {  0,  "audio/wp_flump_explo-01.wv", },
	/* x1989[1] */ {  0,  "audio/wp_flump_explo-02.wv", },
	/* x1989[2] */ {  0,  "audio/wp_flump_explo-03.wv", },
};
static CDataSound x2005[] = {
	/* x2005[0] */ {  0,  "audio/wp_ninja_hit-01.wv", },
	/* x2005[1] */ {  0,  "audio/wp_ninja_hit-02.wv", },
	/* x2005[2] */ {  0,  "audio/wp_ninja_hit-03.wv", },
};
static CDataSound x2021[] = {
	/* x2021[0] */ {  0,  "audio/wp_laser_fire-01.wv", },
	/* x2021[1] */ {  0,  "audio/wp_laser_fire-02.wv", },
	/* x2021[2] */ {  0,  "audio/wp_laser_fire-03.wv", },
};
static CDataSound x2037[] = {
	/* x2037[0] */ {  0,  "audio/wp_laser_bnce-01.wv", },
	/* x2037[1] */ {  0,  "audio/wp_laser_bnce-02.wv", },
	/* x2037[2] */ {  0,  "audio/wp_laser_bnce-03.wv", },
};
static CDataSound x2053[] = {
	/* x2053[0] */ {  0,  "audio/wp_switch-01.wv", },
	/* x2053[1] */ {  0,  "audio/wp_switch-02.wv", },
	/* x2053[2] */ {  0,  "audio/wp_switch-03.wv", },
};
static CDataSound x2069[] = {
	/* x2069[0] */ {  0,  "audio/vo_teefault_pain_short-01.wv", },
	/* x2069[1] */ {  0,  "audio/vo_teefault_pain_short-02.wv", },
	/* x2069[2] */ {  0,  "audio/vo_teefault_pain_short-03.wv", },
	/* x2069[3] */ {  0,  "audio/vo_teefault_pain_short-04.wv", },
	/* x2069[4] */ {  0,  "audio/vo_teefault_pain_short-05.wv", },
	/* x2069[5] */ {  0,  "audio/vo_teefault_pain_short-06.wv", },
	/* x2069[6] */ {  0,  "audio/vo_teefault_pain_short-07.wv", },
	/* x2069[7] */ {  0,  "audio/vo_teefault_pain_short-08.wv", },
	/* x2069[8] */ {  0,  "audio/vo_teefault_pain_short-09.wv", },
	/* x2069[9] */ {  0,  "audio/vo_teefault_pain_short-10.wv", },
	/* x2069[10] */ {  0,  "audio/vo_teefault_pain_short-11.wv", },
	/* x2069[11] */ {  0,  "audio/vo_teefault_pain_short-12.wv", },
};
static CDataSound x2112[] = {
	/* x2112[0] */ {  0,  "audio/vo_teefault_pain_long-01.wv", },
	/* x2112[1] */ {  0,  "audio/vo_teefault_pain_long-02.wv", },
};
static CDataSound x2125[] = {
	/* x2125[0] */ {  0,  "audio/foley_land-01.wv", },
	/* x2125[1] */ {  0,  "audio/foley_land-02.wv", },
	/* x2125[2] */ {  0,  "audio/foley_land-03.wv", },
	/* x2125[3] */ {  0,  "audio/foley_land-04.wv", },
};
static CDataSound x2144[] = {
	/* x2144[0] */ {  0,  "audio/foley_dbljump-01.wv", },
	/* x2144[1] */ {  0,  "audio/foley_dbljump-02.wv", },
	/* x2144[2] */ {  0,  "audio/foley_dbljump-03.wv", },
};
static CDataSound x2160[] = {
	/* x2160[0] */ {  0,  "audio/foley_foot_left-01.wv", },
	/* x2160[1] */ {  0,  "audio/foley_foot_left-02.wv", },
	/* x2160[2] */ {  0,  "audio/foley_foot_left-03.wv", },
	/* x2160[3] */ {  0,  "audio/foley_foot_left-04.wv", },
	/* x2160[4] */ {  0,  "audio/foley_foot_right-01.wv", },
	/* x2160[5] */ {  0,  "audio/foley_foot_right-02.wv", },
	/* x2160[6] */ {  0,  "audio/foley_foot_right-03.wv", },
	/* x2160[7] */ {  0,  "audio/foley_foot_right-04.wv", },
};
static CDataSound x2191[] = {
	/* x2191[0] */ {  0,  "audio/foley_body_splat-01.wv", },
	/* x2191[1] */ {  0,  "audio/foley_body_splat-02.wv", },
	/* x2191[2] */ {  0,  "audio/foley_body_splat-03.wv", },
};
static CDataSound x2207[] = {
	/* x2207[0] */ {  0,  "audio/vo_teefault_spawn-01.wv", },
	/* x2207[1] */ {  0,  "audio/vo_teefault_spawn-02.wv", },
	/* x2207[2] */ {  0,  "audio/vo_teefault_spawn-03.wv", },
	/* x2207[3] */ {  0,  "audio/vo_teefault_spawn-04.wv", },
	/* x2207[4] */ {  0,  "audio/vo_teefault_spawn-05.wv", },
	/* x2207[5] */ {  0,  "audio/vo_teefault_spawn-06.wv", },
	/* x2207[6] */ {  0,  "audio/vo_teefault_spawn-07.wv", },
};
static CDataSound x2235[] = {
	/* x2235[0] */ {  0,  "audio/sfx_skid-01.wv", },
	/* x2235[1] */ {  0,  "audio/sfx_skid-02.wv", },
	/* x2235[2] */ {  0,  "audio/sfx_skid-03.wv", },
	/* x2235[3] */ {  0,  "audio/sfx_skid-04.wv", },
};
static CDataSound x2254[] = {
	/* x2254[0] */ {  0,  "audio/vo_teefault_cry-01.wv", },
	/* x2254[1] */ {  0,  "audio/vo_teefault_cry-02.wv", },
};
static CDataSound x2267[] = {
	/* x2267[0] */ {  0,  "audio/hook_loop-01.wv", },
	/* x2267[1] */ {  0,  "audio/hook_loop-02.wv", },
};
static CDataSound x2280[] = {
	/* x2280[0] */ {  0,  "audio/hook_attach-01.wv", },
	/* x2280[1] */ {  0,  "audio/hook_attach-02.wv", },
	/* x2280[2] */ {  0,  "audio/hook_attach-03.wv", },
};
static CDataSound x2296[] = {
	/* x2296[0] */ {  0,  "audio/foley_body_impact-01.wv", },
	/* x2296[1] */ {  0,  "audio/foley_body_impact-02.wv", },
	/* x2296[2] */ {  0,  "audio/foley_body_impact-03.wv", },
};
static CDataSound x2312[] = {
	/* x2312[0] */ {  0,  "audio/hook_noattach-01.wv", },
	/* x2312[1] */ {  0,  "audio/hook_noattach-02.wv", },
};
static CDataSound x2325[] = {
	/* x2325[0] */ {  0,  "audio/sfx_pickup_hrt-01.wv", },
	/* x2325[1] */ {  0,  "audio/sfx_pickup_hrt-02.wv", },
};
static CDataSound x2338[] = {
	/* x2338[0] */ {  0,  "audio/sfx_pickup_arm-01.wv", },
	/* x2338[1] */ {  0,  "audio/sfx_pickup_arm-02.wv", },
	/* x2338[2] */ {  0,  "audio/sfx_pickup_arm-03.wv", },
	/* x2338[3] */ {  0,  "audio/sfx_pickup_arm-04.wv", },
};
static CDataSound x2357[] = {
	/* x2357[0] */ {  0,  "audio/sfx_pickup_launcher.wv", },
};
static CDataSound x2367[] = {
	/* x2367[0] */ {  0,  "audio/sfx_pickup_sg.wv", },
};
static CDataSound x2377[] = {
	/* x2377[0] */ {  0,  "audio/sfx_pickup_ninja.wv", },
};
static CDataSound x2387[] = {
	/* x2387[0] */ {  0,  "audio/sfx_spawn_wpn-01.wv", },
	/* x2387[1] */ {  0,  "audio/sfx_spawn_wpn-02.wv", },
	/* x2387[2] */ {  0,  "audio/sfx_spawn_wpn-03.wv", },
};
static CDataSound x2403[] = {
	/* x2403[0] */ {  0,  "audio/wp_noammo-01.wv", },
	/* x2403[1] */ {  0,  "audio/wp_noammo-02.wv", },
	/* x2403[2] */ {  0,  "audio/wp_noammo-03.wv", },
	/* x2403[3] */ {  0,  "audio/wp_noammo-04.wv", },
	/* x2403[4] */ {  0,  "audio/wp_noammo-05.wv", },
};
static CDataSound x2425[] = {
	/* x2425[0] */ {  0,  "audio/sfx_hit_weak-01.wv", },
	/* x2425[1] */ {  0,  "audio/sfx_hit_weak-02.wv", },
};
static CDataSound x2438[] = {
	/* x2438[0] */ {  0,  "audio/sfx_msg-server.wv", },
};
static CDataSound x2448[] = {
	/* x2448[0] */ {  0,  "audio/sfx_msg-client.wv", },
};
static CDataSound x2458[] = {
	/* x2458[0] */ {  0,  "audio/sfx_msg-highlight.wv", },
};
static CDataSound x2468[] = {
	/* x2468[0] */ {  0,  "audio/sfx_ctf_drop.wv", },
};
static CDataSound x2478[] = {
	/* x2478[0] */ {  0,  "audio/sfx_ctf_rtn.wv", },
};
static CDataSound x2488[] = {
	/* x2488[0] */ {  0,  "audio/sfx_ctf_grab_pl.wv", },
};
static CDataSound x2498[] = {
	/* x2498[0] */ {  0,  "audio/sfx_ctf_grab_en.wv", },
};
static CDataSound x2508[] = {
	/* x2508[0] */ {  0,  "audio/sfx_ctf_cap_pl.wv", },
};
static CDataSound x2518[] = {
	/* x2518[0] */ {  0,  "audio/music_menu.wv", },
};
static CDataSoundset x9[] = {
	/* x9[0] */ {  "gun_fire",  3,x1893,  -1, },
	/* x9[1] */ {  "shotgun_fire",  3,x1909,  -1, },
	/* x9[2] */ {  "grenade_fire",  3,x1925,  -1, },
	/* x9[3] */ {  "hammer_fire",  3,x1941,  -1, },
	/* x9[4] */ {  "hammer_hit",  3,x1957,  -1, },
	/* x9[5] */ {  "ninja_fire",  3,x1973,  -1, },
	/* x9[6] */ {  "grenade_explode",  3,x1989,  -1, },
	/* x9[7] */ {  "ninja_hit",  3,x2005,  -1, },
	/* x9[8] */ {  "laser_fire",  3,x2021,  -1, },
	/* x9[9] */ {  "laser_bounce",  3,x2037,  -1, },
	/* x9[10] */ {  "weapon_switch",  3,x2053,  -1, },
	/* x9[11] */ {  "player_pain_short",  12,x2069,  -1, },
	/* x9[12] */ {  "player_pain_long",  2,x2112,  -1, },
	/* x9[13] */ {  "body_land",  4,x2125,  -1, },
	/* x9[14] */ {  "player_airjump",  3,x2144,  -1, },
	/* x9[15] */ {  "player_jump",  8,x2160,  -1, },
	/* x9[16] */ {  "player_die",  3,x2191,  -1, },
	/* x9[17] */ {  "player_spawn",  7,x2207,  -1, },
	/* x9[18] */ {  "player_skid",  4,x2235,  -1, },
	/* x9[19] */ {  "tee_cry",  2,x2254,  -1, },
	/* x9[20] */ {  "hook_loop",  2,x2267,  -1, },
	/* x9[21] */ {  "hook_attach_ground",  3,x2280,  -1, },
	/* x9[22] */ {  "hook_attach_player",  3,x2296,  -1, },
	/* x9[23] */ {  "hook_noattach",  2,x2312,  -1, },
	/* x9[24] */ {  "pickup_health",  2,x2325,  -1, },
	/* x9[25] */ {  "pickup_armor",  4,x2338,  -1, },
	/* x9[26] */ {  "pickup_grenade",  1,x2357,  -1, },
	/* x9[27] */ {  "pickup_shotgun",  1,x2367,  -1, },
	/* x9[28] */ {  "pickup_ninja",  1,x2377,  -1, },
	/* x9[29] */ {  "weapon_spawn",  3,x2387,  -1, },
	/* x9[30] */ {  "weapon_noammo",  5,x2403,  -1, },
	/* x9[31] */ {  "hit",  2,x2425,  -1, },
	/* x9[32] */ {  "chat_server",  1,x2438,  -1, },
	/* x9[33] */ {  "chat_client",  1,x2448,  -1, },
	/* x9[34] */ {  "chat_highlight",  1,x2458,  -1, },
	/* x9[35] */ {  "ctf_drop",  1,x2468,  -1, },
	/* x9[36] */ {  "ctf_return",  1,x2478,  -1, },
	/* x9[37] */ {  "ctf_grab_pl",  1,x2488,  -1, },
	/* x9[38] */ {  "ctf_grab_en",  1,x2498,  -1, },
	/* x9[39] */ {  "ctf_capture",  1,x2508,  -1, },
	/* x9[40] */ {  "menu",  1,x2518,  -1, },
};
static CDataImage x14[] = {
	/* x14[0] */ {  "null",  "",  IGraphics::CTextureHandle(), },
	/* x14[1] */ {  "game",  "game.png",  IGraphics::CTextureHandle(), },
	/* x14[2] */ {  "particles",  "particles.png",  IGraphics::CTextureHandle(), },
	/* x14[3] */ {  "cursor",  "gui_cursor.png",  IGraphics::CTextureHandle(), },
	/* x14[4] */ {  "banner",  "gui_logo.png",  IGraphics::CTextureHandle(), },
	/* x14[5] */ {  "emoticons",  "emoticons.png",  IGraphics::CTextureHandle(), },
	/* x14[6] */ {  "console_bg",  "console.png",  IGraphics::CTextureHandle(), },
	/* x14[7] */ {  "console_bar",  "console_bar.png",  IGraphics::CTextureHandle(), },
	/* x14[8] */ {  "speedup_arrow",  "editor/speed_arrow.png",  IGraphics::CTextureHandle(), },
	/* x14[9] */ {  "guibuttons",  "gui_buttons.png",  IGraphics::CTextureHandle(), },
	/* x14[10] */ {  "guiicons",  "gui_icons.png",  IGraphics::CTextureHandle(), },
	/* x14[11] */ {  "arrow",  "arrow.png",  IGraphics::CTextureHandle(), },
	/* x14[12] */ {  "audio_source",  "editor/audio_source.png",  IGraphics::CTextureHandle(), },
	/* x14[13] */ {  "strongweak",  "strong_weak.png",  IGraphics::CTextureHandle(), },
	/* x14[14] */ {  "hud",  "hud.png",  IGraphics::CTextureHandle(), },
	/* x14[15] */ {  "extras",  "extras.png",  IGraphics::CTextureHandle(), },
};
static CDataPickupspec x19[] = {
	/* x19[0] */ {  "health",  15,  0, },
	/* x19[1] */ {  "armor",  15,  0, },
	/* x19[2] */ {  "armor_shotgun",  15,  0, },
	/* x19[3] */ {  "armor_grenade",  15,  0, },
	/* x19[4] */ {  "armor_laser",  15,  0, },
	/* x19[5] */ {  "armor_ninja",  15,  0, },
	/* x19[6] */ {  "weapon",  15,  0, },
	/* x19[7] */ {  "ninja",  90,  90, },
};
static CDataSpriteset x28[] = {
	/* x28[0] */ {  &x14[2],  8,  8, },
	/* x28[1] */ {  &x14[1],  32,  16, },
	/* x28[2] */ {  &x14[0],  8,  4, },
	/* x28[3] */ {  &x14[5],  4,  4, },
	/* x28[4] */ {  &x14[8],  1,  1, },
	/* x28[5] */ {  &x14[9],  12,  4, },
	/* x28[6] */ {  &x14[10],  12,  2, },
	/* x28[7] */ {  &x14[12],  1,  1, },
	/* x28[8] */ {  &x14[13],  2,  1, },
	/* x28[9] */ {  &x14[14],  16,  16, },
	/* x28[10] */ {  &x14[15],  16,  16, },
};
static CDataSprite x44[] = {
	/* x44[0] */ {  "part_slice",  &x28[0],  0,  0,  1,  1, },
	/* x44[1] */ {  "part_ball",  &x28[0],  1,  0,  1,  1, },
	/* x44[2] */ {  "part_splat01",  &x28[0],  2,  0,  1,  1, },
	/* x44[3] */ {  "part_splat02",  &x28[0],  3,  0,  1,  1, },
	/* x44[4] */ {  "part_splat03",  &x28[0],  4,  0,  1,  1, },
	/* x44[5] */ {  "part_smoke",  &x28[0],  0,  1,  1,  1, },
	/* x44[6] */ {  "part_shell",  &x28[0],  0,  2,  2,  2, },
	/* x44[7] */ {  "part_expl01",  &x28[0],  0,  4,  4,  4, },
	/* x44[8] */ {  "part_airjump",  &x28[0],  2,  2,  2,  2, },
	/* x44[9] */ {  "part_hit01",  &x28[0],  4,  1,  2,  2, },
	/* x44[10] */ {  "health_full",  &x28[1],  21,  0,  2,  2, },
	/* x44[11] */ {  "health_empty",  &x28[1],  23,  0,  2,  2, },
	/* x44[12] */ {  "armor_full",  &x28[1],  21,  2,  2,  2, },
	/* x44[13] */ {  "armor_empty",  &x28[1],  23,  2,  2,  2, },
	/* x44[14] */ {  "star1",  &x28[1],  15,  0,  2,  2, },
	/* x44[15] */ {  "star2",  &x28[1],  17,  0,  2,  2, },
	/* x44[16] */ {  "star3",  &x28[1],  19,  0,  2,  2, },
	/* x44[17] */ {  "part1",  &x28[1],  6,  0,  1,  1, },
	/* x44[18] */ {  "part2",  &x28[1],  6,  1,  1,  1, },
	/* x44[19] */ {  "part3",  &x28[1],  7,  0,  1,  1, },
	/* x44[20] */ {  "part4",  &x28[1],  7,  1,  1,  1, },
	/* x44[21] */ {  "part5",  &x28[1],  8,  0,  1,  1, },
	/* x44[22] */ {  "part6",  &x28[1],  8,  1,  1,  1, },
	/* x44[23] */ {  "part7",  &x28[1],  9,  0,  2,  2, },
	/* x44[24] */ {  "part8",  &x28[1],  11,  0,  2,  2, },
	/* x44[25] */ {  "part9",  &x28[1],  13,  0,  2,  2, },
	/* x44[26] */ {  "weapon_gun_body",  &x28[1],  2,  4,  4,  2, },
	/* x44[27] */ {  "weapon_gun_cursor",  &x28[1],  0,  4,  2,  2, },
	/* x44[28] */ {  "weapon_gun_proj",  &x28[1],  6,  4,  2,  2, },
	/* x44[29] */ {  "weapon_gun_muzzle1",  &x28[1],  8,  4,  4,  2, },
	/* x44[30] */ {  "weapon_gun_muzzle2",  &x28[1],  12,  4,  4,  2, },
	/* x44[31] */ {  "weapon_gun_muzzle3",  &x28[1],  16,  4,  4,  2, },
	/* x44[32] */ {  "weapon_shotgun_body",  &x28[1],  2,  6,  8,  2, },
	/* x44[33] */ {  "weapon_shotgun_cursor",  &x28[1],  0,  6,  2,  2, },
	/* x44[34] */ {  "weapon_shotgun_proj",  &x28[1],  10,  6,  2,  2, },
	/* x44[35] */ {  "weapon_shotgun_muzzle1",  &x28[1],  12,  6,  4,  2, },
	/* x44[36] */ {  "weapon_shotgun_muzzle2",  &x28[1],  16,  6,  4,  2, },
	/* x44[37] */ {  "weapon_shotgun_muzzle3",  &x28[1],  20,  6,  4,  2, },
	/* x44[38] */ {  "weapon_grenade_body",  &x28[1],  2,  8,  7,  2, },
	/* x44[39] */ {  "weapon_grenade_cursor",  &x28[1],  0,  8,  2,  2, },
	/* x44[40] */ {  "weapon_grenade_proj",  &x28[1],  10,  8,  2,  2, },
	/* x44[41] */ {  "weapon_hammer_body",  &x28[1],  2,  1,  4,  3, },
	/* x44[42] */ {  "weapon_hammer_cursor",  &x28[1],  0,  0,  2,  2, },
	/* x44[43] */ {  "weapon_hammer_proj",  &x28[1],  0,  0,  0,  0, },
	/* x44[44] */ {  "weapon_ninja_body",  &x28[1],  2,  10,  8,  2, },
	/* x44[45] */ {  "weapon_ninja_cursor",  &x28[1],  0,  10,  2,  2, },
	/* x44[46] */ {  "weapon_ninja_proj",  &x28[1],  0,  0,  0,  0, },
	/* x44[47] */ {  "weapon_laser_body",  &x28[1],  2,  12,  7,  3, },
	/* x44[48] */ {  "weapon_laser_cursor",  &x28[1],  0,  12,  2,  2, },
	/* x44[49] */ {  "weapon_laser_proj",  &x28[1],  10,  12,  2,  2, },
	/* x44[50] */ {  "hook_chain",  &x28[1],  2,  0,  1,  1, },
	/* x44[51] */ {  "hook_head",  &x28[1],  3,  0,  2,  1, },
	/* x44[52] */ {  "weapon_ninja_muzzle1",  &x28[1],  25,  0,  7,  4, },
	/* x44[53] */ {  "weapon_ninja_muzzle2",  &x28[1],  25,  4,  7,  4, },
	/* x44[54] */ {  "weapon_ninja_muzzle3",  &x28[1],  25,  8,  7,  4, },
	/* x44[55] */ {  "pickup_health",  &x28[1],  10,  2,  2,  2, },
	/* x44[56] */ {  "pickup_armor",  &x28[1],  12,  2,  2,  2, },
	/* x44[57] */ {  "pickup_hammer",  &x28[1],  2,  1,  4,  3, },
	/* x44[58] */ {  "pickup_gun",  &x28[1],  2,  4,  4,  2, },
	/* x44[59] */ {  "pickup_shotgun",  &x28[1],  2,  6,  8,  2, },
	/* x44[60] */ {  "pickup_grenade",  &x28[1],  2,  8,  7,  2, },
	/* x44[61] */ {  "pickup_laser",  &x28[1],  2,  12,  7,  3, },
	/* x44[62] */ {  "pickup_ninja",  &x28[1],  2,  10,  8,  2, },
	/* x44[63] */ {  "pickup_armor_shotgun",  &x28[1],  15,  2,  2,  2, },
	/* x44[64] */ {  "pickup_armor_grenade",  &x28[1],  17,  2,  2,  2, },
	/* x44[65] */ {  "pickup_armor_ninja",  &x28[1],  10,  10,  2,  2, },
	/* x44[66] */ {  "pickup_armor_laser",  &x28[1],  19,  2,  2,  2, },
	/* x44[67] */ {  "flag_blue",  &x28[1],  12,  8,  4,  8, },
	/* x44[68] */ {  "flag_red",  &x28[1],  16,  8,  4,  8, },
	/* x44[69] */ {  "tee_body",  &x28[2],  0,  0,  3,  3, },
	/* x44[70] */ {  "tee_body_outline",  &x28[2],  3,  0,  3,  3, },
	/* x44[71] */ {  "tee_foot",  &x28[2],  6,  1,  2,  1, },
	/* x44[72] */ {  "tee_foot_outline",  &x28[2],  6,  2,  2,  1, },
	/* x44[73] */ {  "tee_hand",  &x28[2],  6,  0,  1,  1, },
	/* x44[74] */ {  "tee_hand_outline",  &x28[2],  7,  0,  1,  1, },
	/* x44[75] */ {  "tee_eye_normal",  &x28[2],  2,  3,  1,  1, },
	/* x44[76] */ {  "tee_eye_angry",  &x28[2],  3,  3,  1,  1, },
	/* x44[77] */ {  "tee_eye_pain",  &x28[2],  4,  3,  1,  1, },
	/* x44[78] */ {  "tee_eye_happy",  &x28[2],  5,  3,  1,  1, },
	/* x44[79] */ {  "tee_eye_dead",  &x28[2],  6,  3,  1,  1, },
	/* x44[80] */ {  "tee_eye_surprise",  &x28[2],  7,  3,  1,  1, },
	/* x44[81] */ {  "oop",  &x28[3],  0,  0,  1,  1, },
	/* x44[82] */ {  "exclamation",  &x28[3],  1,  0,  1,  1, },
	/* x44[83] */ {  "hearts",  &x28[3],  2,  0,  1,  1, },
	/* x44[84] */ {  "drop",  &x28[3],  3,  0,  1,  1, },
	/* x44[85] */ {  "dotdot",  &x28[3],  0,  1,  1,  1, },
	/* x44[86] */ {  "music",  &x28[3],  1,  1,  1,  1, },
	/* x44[87] */ {  "sorry",  &x28[3],  2,  1,  1,  1, },
	/* x44[88] */ {  "ghost",  &x28[3],  3,  1,  1,  1, },
	/* x44[89] */ {  "sushi",  &x28[3],  0,  2,  1,  1, },
	/* x44[90] */ {  "splattee",  &x28[3],  1,  2,  1,  1, },
	/* x44[91] */ {  "deviltee",  &x28[3],  2,  2,  1,  1, },
	/* x44[92] */ {  "zomg",  &x28[3],  3,  2,  1,  1, },
	/* x44[93] */ {  "zzz",  &x28[3],  0,  3,  1,  1, },
	/* x44[94] */ {  "wtf",  &x28[3],  1,  3,  1,  1, },
	/* x44[95] */ {  "eyes",  &x28[3],  2,  3,  1,  1, },
	/* x44[96] */ {  "question",  &x28[3],  3,  3,  1,  1, },
	/* x44[97] */ {  "speedup_arrow",  &x28[4],  0,  0,  1,  1, },
	/* x44[98] */ {  "guibutton_off",  &x28[5],  0,  0,  4,  4, },
	/* x44[99] */ {  "guibutton_on",  &x28[5],  4,  0,  4,  4, },
	/* x44[100] */ {  "guibutton_hover",  &x28[5],  8,  0,  4,  4, },
	/* x44[101] */ {  "guiicon_mute",  &x28[6],  0,  0,  4,  2, },
	/* x44[102] */ {  "guiicon_emoticon_mute",  &x28[6],  4,  0,  4,  2, },
	/* x44[103] */ {  "guiicon_friend",  &x28[6],  8,  0,  4,  2, },
	/* x44[104] */ {  "audio_source",  &x28[7],  0,  0,  1,  1, },
	/* x44[105] */ {  "hook_strong",  &x28[8],  0,  0,  1,  1, },
	/* x44[106] */ {  "hook_weak",  &x28[8],  1,  0,  1,  1, },
	/* x44[107] */ {  "hud_airjump",  &x28[9],  0,  0,  2,  2, },
	/* x44[108] */ {  "hud_airjump_empty",  &x28[9],  2,  0,  2,  2, },
	/* x44[109] */ {  "hud_solo",  &x28[9],  4,  0,  2,  2, },
	/* x44[110] */ {  "hud_collision_disabled",  &x28[9],  6,  0,  2,  2, },
	/* x44[111] */ {  "hud_endless_jump",  &x28[9],  8,  0,  2,  2, },
	/* x44[112] */ {  "hud_endless_hook",  &x28[9],  10,  0,  2,  2, },
	/* x44[113] */ {  "hud_jetpack",  &x28[9],  12,  0,  2,  2, },
	/* x44[114] */ {  "hud_freeze_bar_full_left",  &x28[9],  0,  2,  1,  1, },
	/* x44[115] */ {  "hud_freeze_bar_full",  &x28[9],  1,  2,  1,  1, },
	/* x44[116] */ {  "hud_freeze_bar_empty",  &x28[9],  2,  2,  1,  1, },
	/* x44[117] */ {  "hud_freeze_bar_empty_right",  &x28[9],  3,  2,  1,  1, },
	/* x44[118] */ {  "hud_ninja_bar_full_left",  &x28[9],  0,  3,  1,  1, },
	/* x44[119] */ {  "hud_ninja_bar_full",  &x28[9],  1,  3,  1,  1, },
	/* x44[120] */ {  "hud_ninja_bar_empty",  &x28[9],  2,  3,  1,  1, },
	/* x44[121] */ {  "hud_ninja_bar_empty_right",  &x28[9],  3,  3,  1,  1, },
	/* x44[122] */ {  "hud_hook_hit_disabled",  &x28[9],  4,  2,  2,  2, },
	/* x44[123] */ {  "hud_hammer_hit_disabled",  &x28[9],  6,  2,  2,  2, },
	/* x44[124] */ {  "hud_shotgun_hit_disabled",  &x28[9],  8,  2,  2,  2, },
	/* x44[125] */ {  "hud_grenade_hit_disabled",  &x28[9],  10,  2,  2,  2, },
	/* x44[126] */ {  "hud_laser_hit_disabled",  &x28[9],  12,  2,  2,  2, },
	/* x44[127] */ {  "hud_gun_hit_disabled",  &x28[9],  14,  2,  2,  2, },
	/* x44[128] */ {  "hud_deep_frozen",  &x28[9],  10,  4,  2,  2, },
	/* x44[129] */ {  "hud_live_frozen",  &x28[9],  12,  4,  2,  2, },
	/* x44[130] */ {  "hud_teleport_grenade",  &x28[9],  4,  4,  2,  2, },
	/* x44[131] */ {  "hud_teleport_gun",  &x28[9],  6,  4,  2,  2, },
	/* x44[132] */ {  "hud_teleport_laser",  &x28[9],  8,  4,  2,  2, },
	/* x44[133] */ {  "hud_practice_mode",  &x28[9],  4,  6,  2,  2, },
	/* x44[134] */ {  "hud_dummy_hammer",  &x28[9],  6,  6,  2,  2, },
	/* x44[135] */ {  "hud_dummy_copy",  &x28[9],  8,  6,  2,  2, },
	/* x44[136] */ {  "part_snowflake",  &x28[10],  0,  0,  2,  2, },
};
static CAnimKeyframe x4770[] = {
	/* x4770[0] */ {  0.000000f,  0.000000f,  -4.000000f,  0.000000f, },
};
static CAnimKeyframe x4777[] = {
	/* x4777[0] */ {  0.000000f,  0.000000f,  10.000000f,  0.000000f, },
};
static CAnimKeyframe x4784[] = {
	/* x4784[0] */ {  0.000000f,  0.000000f,  10.000000f,  0.000000f, },
};
static CAnimKeyframe *x4791 = 0;
static CAnimKeyframe *x4815 = 0;
static CAnimKeyframe x4822[] = {
	/* x4822[0] */ {  0.000000f,  -7.000000f,  0.000000f,  0.000000f, },
};
static CAnimKeyframe x4829[] = {
	/* x4829[0] */ {  0.000000f,  7.000000f,  0.000000f,  0.000000f, },
};
static CAnimKeyframe *x4836 = 0;
static CAnimKeyframe *x4855 = 0;
static CAnimKeyframe x4862[] = {
	/* x4862[0] */ {  0.000000f,  -3.000000f,  0.000000f,  -0.100000f, },
};
static CAnimKeyframe x4869[] = {
	/* x4869[0] */ {  0.000000f,  3.000000f,  0.000000f,  -0.100000f, },
};
static CAnimKeyframe *x4876 = 0;
static CAnimKeyframe x4895[] = {
	/* x4895[0] */ {  0.000000f,  0.000000f,  3.000000f,  0.000000f, },
};
static CAnimKeyframe x4902[] = {
	/* x4902[0] */ {  0.000000f,  -12.000000f,  0.000000f,  0.100000f, },
};
static CAnimKeyframe x4909[] = {
	/* x4909[0] */ {  0.000000f,  -8.000000f,  0.000000f,  0.100000f, },
};
static CAnimKeyframe *x4916 = 0;
static CAnimKeyframe x4940[] = {
	/* x4940[0] */ {  0.000000f,  0.000000f,  3.000000f,  0.000000f, },
};
static CAnimKeyframe x4947[] = {
	/* x4947[0] */ {  0.000000f,  12.000000f,  0.000000f,  -0.100000f, },
};
static CAnimKeyframe x4954[] = {
	/* x4954[0] */ {  0.000000f,  8.000000f,  0.000000f,  -0.100000f, },
};
static CAnimKeyframe *x4961 = 0;
static CAnimKeyframe x4985[] = {
	/* x4985[0] */ {  0.000000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x4985[1] */ {  0.200000f,  0.000000f,  -1.000000f,  0.000000f, },
	/* x4985[2] */ {  0.400000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x4985[3] */ {  0.600000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x4985[4] */ {  0.800000f,  0.000000f,  -1.000000f,  0.000000f, },
	/* x4985[5] */ {  1.000000f,  0.000000f,  0.000000f,  0.000000f, },
};
static CAnimKeyframe x4992[] = {
	/* x4992[0] */ {  0.000000f,  8.000000f,  0.000000f,  0.000000f, },
	/* x4992[1] */ {  0.200000f,  -8.000000f,  0.000000f,  0.000000f, },
	/* x4992[2] */ {  0.400000f,  -10.000000f,  -4.000000f,  0.200000f, },
	/* x4992[3] */ {  0.600000f,  -8.000000f,  -8.000000f,  0.300000f, },
	/* x4992[4] */ {  0.800000f,  4.000000f,  -4.000000f,  -0.200000f, },
	/* x4992[5] */ {  1.000000f,  8.000000f,  0.000000f,  0.000000f, },
};
static CAnimKeyframe x4999[] = {
	/* x4999[0] */ {  0.000000f,  -10.000000f,  -4.000000f,  0.200000f, },
	/* x4999[1] */ {  0.200000f,  -8.000000f,  -8.000000f,  0.300000f, },
	/* x4999[2] */ {  0.400000f,  4.000000f,  -4.000000f,  -0.200000f, },
	/* x4999[3] */ {  0.600000f,  8.000000f,  0.000000f,  0.000000f, },
	/* x4999[4] */ {  0.800000f,  8.000000f,  0.000000f,  0.000000f, },
	/* x4999[5] */ {  1.000000f,  -10.000000f,  -4.000000f,  0.200000f, },
};
static CAnimKeyframe *x5006 = 0;
static CAnimKeyframe x5105[] = {
	/* x5105[0] */ {  0.000000f,  0.000000f,  -1.000000f,  0.000000f, },
	/* x5105[1] */ {  0.200000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x5105[2] */ {  0.400000f,  0.000000f,  -1.000000f,  0.000000f, },
	/* x5105[3] */ {  0.600000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x5105[4] */ {  0.800000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x5105[5] */ {  1.000000f,  0.000000f,  -1.000000f,  0.000000f, },
};
static CAnimKeyframe x5112[] = {
	/* x5112[0] */ {  0.000000f,  18.000000f,  -8.000000f,  -0.270000f, },
	/* x5112[1] */ {  0.200000f,  6.000000f,  0.000000f,  0.000000f, },
	/* x5112[2] */ {  0.400000f,  -7.000000f,  0.000000f,  0.000000f, },
	/* x5112[3] */ {  0.600000f,  -13.000000f,  -4.500000f,  0.050000f, },
	/* x5112[4] */ {  0.800000f,  0.000000f,  -8.000000f,  -0.200000f, },
	/* x5112[5] */ {  1.000000f,  18.000000f,  -8.000000f,  -0.270000f, },
};
static CAnimKeyframe x5119[] = {
	/* x5119[0] */ {  0.000000f,  -11.000000f,  -2.500000f,  0.050000f, },
	/* x5119[1] */ {  0.200000f,  -14.000000f,  -5.000000f,  0.100000f, },
	/* x5119[2] */ {  0.400000f,  11.000000f,  -8.000000f,  -0.300000f, },
	/* x5119[3] */ {  0.600000f,  18.000000f,  -8.000000f,  -0.270000f, },
	/* x5119[4] */ {  0.800000f,  3.000000f,  0.000000f,  0.000000f, },
	/* x5119[5] */ {  1.000000f,  -11.000000f,  -2.500000f,  0.050000f, },
};
static CAnimKeyframe *x5126 = 0;
static CAnimKeyframe x5225[] = {
	/* x5225[0] */ {  0.000000f,  0.000000f,  -1.000000f,  0.000000f, },
	/* x5225[1] */ {  0.200000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x5225[2] */ {  0.400000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x5225[3] */ {  0.600000f,  0.000000f,  -1.000000f,  0.000000f, },
	/* x5225[4] */ {  0.800000f,  0.000000f,  0.000000f,  0.000000f, },
	/* x5225[5] */ {  1.000000f,  0.000000f,  -1.000000f,  0.000000f, },
};
static CAnimKeyframe x5232[] = {
	/* x5232[0] */ {  0.000000f,  -18.000000f,  -8.000000f,  0.270000f, },
	/* x5232[1] */ {  0.200000f,  0.000000f,  -8.000000f,  0.200000f, },
	/* x5232[2] */ {  0.400000f,  13.000000f,  -4.500000f,  -0.050000f, },
	/* x5232[3] */ {  0.600000f,  7.000000f,  0.000000f,  0.000000f, },
	/* x5232[4] */ {  0.800000f,  -6.000000f,  0.000000f,  0.000000f, },
	/* x5232[5] */ {  1.000000f,  -18.000000f,  -8.000000f,  0.270000f, },
};
static CAnimKeyframe x5239[] = {
	/* x5239[0] */ {  0.000000f,  11.000000f,  -2.500000f,  -0.050000f, },
	/* x5239[1] */ {  0.200000f,  -3.000000f,  0.000000f,  0.000000f, },
	/* x5239[2] */ {  0.400000f,  -18.000000f,  -8.000000f,  0.270000f, },
	/* x5239[3] */ {  0.600000f,  -11.000000f,  -8.000000f,  0.300000f, },
	/* x5239[4] */ {  0.800000f,  14.000000f,  -5.000000f,  -0.100000f, },
	/* x5239[5] */ {  1.000000f,  11.000000f,  -2.500000f,  -0.050000f, },
};
static CAnimKeyframe *x5246 = 0;
static CAnimKeyframe *x5345 = 0;
static CAnimKeyframe *x5352 = 0;
static CAnimKeyframe *x5359 = 0;
static CAnimKeyframe x5366[] = {
	/* x5366[0] */ {  0.000000f,  0.000000f,  0.000000f,  -0.100000f, },
	/* x5366[1] */ {  0.300000f,  0.000000f,  0.000000f,  0.250000f, },
	/* x5366[2] */ {  0.400000f,  0.000000f,  0.000000f,  0.300000f, },
	/* x5366[3] */ {  0.500000f,  0.000000f,  0.000000f,  0.250000f, },
	/* x5366[4] */ {  1.000000f,  0.000000f,  0.000000f,  -0.100000f, },
};
static CAnimKeyframe *x5400 = 0;
static CAnimKeyframe *x5407 = 0;
static CAnimKeyframe *x5414 = 0;
static CAnimKeyframe x5421[] = {
	/* x5421[0] */ {  0.000000f,  0.000000f,  0.000000f,  -0.250000f, },
	/* x5421[1] */ {  0.100000f,  0.000000f,  0.000000f,  -0.050000f, },
	/* x5421[2] */ {  0.150000f,  0.000000f,  0.000000f,  0.350000f, },
	/* x5421[3] */ {  0.420000f,  0.000000f,  0.000000f,  0.400000f, },
	/* x5421[4] */ {  0.500000f,  0.000000f,  0.000000f,  0.350000f, },
	/* x5421[5] */ {  1.000000f,  0.000000f,  0.000000f,  -0.250000f, },
};
static CAnimation x75[] = {
	/* x75[0] */ {  "base",  /* x75[0].body */ {  1,x4770, },  /* x75[0].back_foot */ {  1,x4777, },  /* x75[0].front_foot */ {  1,x4784, },  /* x75[0].attach */ {  0,x4791, }, },
	/* x75[1] */ {  "idle",  /* x75[1].body */ {  0,x4815, },  /* x75[1].back_foot */ {  1,x4822, },  /* x75[1].front_foot */ {  1,x4829, },  /* x75[1].attach */ {  0,x4836, }, },
	/* x75[2] */ {  "inair",  /* x75[2].body */ {  0,x4855, },  /* x75[2].back_foot */ {  1,x4862, },  /* x75[2].front_foot */ {  1,x4869, },  /* x75[2].attach */ {  0,x4876, }, },
	/* x75[3] */ {  "sit_left",  /* x75[3].body */ {  1,x4895, },  /* x75[3].back_foot */ {  1,x4902, },  /* x75[3].front_foot */ {  1,x4909, },  /* x75[3].attach */ {  0,x4916, }, },
	/* x75[4] */ {  "sit_right",  /* x75[4].body */ {  1,x4940, },  /* x75[4].back_foot */ {  1,x4947, },  /* x75[4].front_foot */ {  1,x4954, },  /* x75[4].attach */ {  0,x4961, }, },
	/* x75[5] */ {  "walk",  /* x75[5].body */ {  6,x4985, },  /* x75[5].back_foot */ {  6,x4992, },  /* x75[5].front_foot */ {  6,x4999, },  /* x75[5].attach */ {  0,x5006, }, },
	/* x75[6] */ {  "run_left",  /* x75[6].body */ {  6,x5105, },  /* x75[6].back_foot */ {  6,x5112, },  /* x75[6].front_foot */ {  6,x5119, },  /* x75[6].attach */ {  0,x5126, }, },
	/* x75[7] */ {  "run_right",  /* x75[7].body */ {  6,x5225, },  /* x75[7].back_foot */ {  6,x5232, },  /* x75[7].front_foot */ {  6,x5239, },  /* x75[7].attach */ {  0,x5246, }, },
	/* x75[8] */ {  "hammer_swing",  /* x75[8].body */ {  0,x5345, },  /* x75[8].back_foot */ {  0,x5352, },  /* x75[8].front_foot */ {  0,x5359, },  /* x75[8].attach */ {  5,x5366, }, },
	/* x75[9] */ {  "ninja_swing",  /* x75[9].body */ {  0,x5400, },  /* x75[9].back_foot */ {  0,x5407, },  /* x75[9].front_foot */ {  0,x5414, },  /* x75[9].attach */ {  6,x5421, }, },
};
static CDataSprite* *x5578 = 0;
static CDataSprite* x5715[] = {
	&x44[29],
	&x44[30],
	&x44[31],
};
static CDataSprite* x5900[] = {
	&x44[35],
	&x44[36],
	&x44[37],
};
static CDataSprite* *x6085 = 0;
static CDataSprite* *x6222 = 0;
static CDataSprite* x6359[] = {
	&x44[52],
	&x44[53],
	&x44[54],
};
static CDataWeaponspec x1887[] = {
	/* x1887[0] */ {  "hammer",  &x44[41],  &x44[42],  &x44[43],  0,x5578,  96,  125,  10,  0,  3,  4.000000f,  -20.000000f,  0.000000f,  0.000000f,  5.000000f, },
	/* x1887[1] */ {  "gun",  &x44[26],  &x44[27],  &x44[28],  3,x5715,  64,  125,  10,  500,  1,  32.000000f,  4.000000f,  58.875200f,  6.000000f,  5.000000f, },
	/* x1887[2] */ {  "shotgun",  &x44[32],  &x44[33],  &x44[34],  3,x5900,  96,  500,  10,  0,  1,  24.000000f,  -2.000000f,  83.312800f,  6.000000f,  5.000000f, },
	/* x1887[3] */ {  "grenade",  &x44[38],  &x44[39],  &x44[40],  0,x6085,  96,  500,  10,  0,  1,  24.000000f,  -2.000000f,  0.000000f,  0.000000f,  5.000000f, },
	/* x1887[4] */ {  "laser",  &x44[47],  &x44[48],  &x44[49],  0,x6222,  92,  800,  10,  0,  5,  24.000000f,  -2.000000f,  0.000000f,  0.000000f,  5.000000f, },
	/* x1887[5] */ {  "ninja",  &x44[44],  &x44[45],  &x44[46],  3,x6359,  96,  800,  10,  0,  9,  0.000000f,  0.000000f,  40.000000f,  -4.000000f,  5.000000f, },
};
CDataContainer datacontainer = 
/* datacontainer */ {
	41,x9,
	16,x14,
	8,x19,
	11,x28,
	137,x44,
	10,x75,
	/* datacontainer.weapons */ { 	/* datacontainer.weapons.hammer */ { 	&x1887[0], }, 	/* datacontainer.weapons.gun */ { 	&x1887[1], 	1.250000f, 	2200.000000f, 	2.000000f, }, 	/* datacontainer.weapons.shotgun */ { 	&x1887[2], 	1.250000f, 	2200.000000f, 	0.800000f, 	0.250000f, }, 	/* datacontainer.weapons.grenade */ { 	&x1887[3], 	7.000000f, 	1000.000000f, 	2.000000f, }, 	/* datacontainer.weapons.laser */ { 	&x1887[4], 	800.000000f, 	150, 	1, 	0.000000f, }, 	/* datacontainer.weapons.ninja */ { 	&x1887[5], 	15000, 	200, 	50, }, 	6,x1887, },
}
;
CDataContainer *g_pData = &datacontainer;
