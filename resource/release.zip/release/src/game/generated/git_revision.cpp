const char *GIT_SHORTREV_HASH = "52f97c358fd897be";
